﻿using System.Configuration;
using System.Data;
using System.Windows;

namespace JSON_Game_of_Thrones_Quotes
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
    }

}
